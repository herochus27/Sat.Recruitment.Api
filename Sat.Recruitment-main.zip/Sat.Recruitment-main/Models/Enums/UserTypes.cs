﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.Text;

namespace Models.Enums
{
    public static class UserTypes
    {
        public const string Normal = "Normal";
        public const string SuperUser = "SuperUser";
        public const string Premium = "Premium";
    }
}
